package Lecture_06_Defining_Classes.Exersices.PokemonTrainer;

import java.util.*;
import java.util.stream.Collectors;

public class PokemonTrainerMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String commandData = scanner.nextLine();
       Map<String, Trainer> trainers = new LinkedHashMap<>();

        while (!commandData.equals("Tournament")) {

            String trainerName = commandData.split("\\s+")[0];
            String pokemonName = commandData.split("\\s+")[1];
            String pokemonElement = commandData.split("\\s+")[2];
            int pokemonHealth = Integer.parseInt(commandData.split("\\s+")[3]);

           if (trainers.containsKey(trainerName)){
               trainers.get(trainerName).getPokemonList().add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));
           }else {
               trainers.put(trainerName, new Trainer(trainerName, new ArrayList<>()));
               trainers.get(trainerName).getPokemonList().add(new Pokemon(pokemonName, pokemonElement, pokemonHealth));

           }

            commandData = scanner.nextLine();
        }

        String commandElements = scanner.nextLine();

        while (!commandElements.equals("End")) {



            for (Map.Entry<String, Trainer> trainerEntry : trainers.entrySet()) {
                boolean isFound = false;
                if (trainerEntry.getValue().getPokemonList().isEmpty()){
                    continue;
                }
                for (Pokemon pokemon : trainerEntry.getValue().getPokemonList()) {
                    if (pokemon.getElement().equals(commandElements)){
                        isFound = true;
                        trainerEntry.getValue().setNumOfBadges(trainerEntry.getValue().getNumOfBadges() + 1);
                        break;
                    }
                }

                if (!isFound){
                    for (Pokemon pokemon : trainerEntry.getValue().getPokemonList()) {
                                    pokemon.setHealth(pokemon.getHealth() - 10);
                                    if (pokemon.getHealth() <= 0){
                                        trainerEntry.getValue().getPokemonList().remove(pokemon);
                                        if (trainerEntry.getValue().getPokemonList().isEmpty()){
                                            break;
                                        }
                                    }
                    }
                }
            }

            commandElements = scanner.nextLine();
        }
        Map<String, Trainer> sortedTrainers = new LinkedHashMap<>();

        trainers.entrySet()
                .stream()
                .sorted((e1, e2) -> {
                    if (e1.getValue().getNumOfBadges() == e2.getValue().getNumOfBadges()){
                        return 1;
                    }else {
                        return Integer.compare(e2.getValue().getNumOfBadges(), e1.getValue().getNumOfBadges());
                    }
                })
                .forEach(entry -> System.out.println(entry.getValue()));










    }
}






