package Lecture_06_Defining_Classes.Exersices.PokemonTrainer;

import java.util.List;

public class Trainer {
    private String name;
    private  int numOfBadges;
    private List<Pokemon> pokemonList;


    public Trainer(String name, List<Pokemon> pokemonList) {
        this.name = name;
        this.numOfBadges = 0;
        this.pokemonList = pokemonList;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumOfBadges() {
        return numOfBadges;
    }

    public void setNumOfBadges(int numOfBadges) {
        this.numOfBadges = numOfBadges;
    }

    public List<Pokemon> getPokemonList() {
        return pokemonList;
    }

    public void setPokemonList(List<Pokemon> pokemonList) {
        this.pokemonList = pokemonList;
    }

    @Override
    public String toString() {
        return String.format("%s %d %d", name, numOfBadges, pokemonList.size());
    }
}
