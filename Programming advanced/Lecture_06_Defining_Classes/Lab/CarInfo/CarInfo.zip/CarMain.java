package Lecture_06_Defining_Classes.CarInfo;

import java.util.Scanner;

public class CarMain {


    public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            int numOfCars = Integer.parseInt(scanner.nextLine());

            while (numOfCars != 0){
                String [] tokens = scanner.nextLine().split("\\s+");

                String carBrand = tokens[0];
                String carModel = tokens[1];
                int carHorsePower = Integer.parseInt(tokens[2]);

                Car car = new Car();

                car.setBrand(carBrand);
                car.setModel(carModel);
                car.setHorsePower(carHorsePower);

                System.out.println(car.carInfo());
                numOfCars--;
            }

        }

    }


