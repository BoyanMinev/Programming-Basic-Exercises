package Lecture_06_Defining_Classes.BankAccount;

import java.util.HashMap;

import java.util.Map;
import java.util.Scanner;

public class mainBankAccount {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


    //•	Create
    //•	Deposit {Id} {Amount}
    //•	SetInterest {Interest}
    //•	GetInterest {ID} {Years}
    //•	End


    String command = scanner.nextLine();


        Map<Integer, BankAccount> bankAccountMap = new HashMap<>();
        while (!command.split("\\s+")[0].equals("End")){
            String firstCommand = command.split("\\s+")[0];
            switch (firstCommand){
            case "Create":
                BankAccount bankAccount = new BankAccount();
                bankAccountMap.put(bankAccount.getId(), bankAccount);
                System.out.printf("Account ID" + bankAccount.getId() +" created");
                System.out.println();

                break;
            case "Deposit":
                int id = Integer.parseInt(command.split("\\s+")[1]);
                double amount = Double.parseDouble(command.split("\\s+")[2]);
                if (bankAccountMap.containsKey(id)){
                    bankAccountMap.get(id).deposit(amount);
                    System.out.printf("Deposited "+ amount + " to ID"+ id);
                    System.out.println();
                }else {
                    System.out.println("Account does not exist");
                }
                break;
            case "SetInterest":
                Double interest = Double.parseDouble(command.split("\\s+")[1]);
                BankAccount.setInterestRate(interest);
                break;
            case"GetInterest":
                id = Integer.parseInt(command.split("\\s+")[1]);
                int years = Integer.parseInt(command.split("\\s+")[2]);

                if (bankAccountMap.containsKey(id)) {
                    System.out.printf("%.2f%n", bankAccountMap.get(id).getInterestRate(years));
                }else {
                    System.out.println("Account does not exist");
                }
                break;


        }

        command = scanner.nextLine();
    }

    }

}
